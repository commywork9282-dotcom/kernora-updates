#!/bin/bash

set -e

SCRIPT_DIR="$(cd -- "$(dirname -- "$0")" && pwd)"
SOURCE_DIR="$(dirname -- "$SCRIPT_DIR")"
BUILD_DIR="$SOURCE_DIR/build"

if [ -z "$KDE_SESSION_VERSION" ]; then
    echo "Not in a KDE Plasma environment to check the desktop effect \"KDE-Rounded-Corners\" support."
    exit 1;
fi

if [ ! -f "$BUILD_DIR/CMakeCache.txt" ]; then
    echo "No configured build directory found at \"$BUILD_DIR\"."
    exit 1
fi

cd -- "$BUILD_DIR"

if ctest > /dev/null; then
    echo "Desktop effect \"KDE-Rounded-Corners\" is compatible with KWin and doesn't need re-installation."
else

    # Find available qdbus binary
    QDBUS_BIN=$(which qdbus6 qdbus-qt6 qdbus 2>/dev/null | head -n 1)
    
    if [ -z "$QDBUS_BIN" ]; then
        echo "qdbus not found. Exiting."
        exit 1
    fi

    kdialog --msgbox "Desktop effect \"KDE-Rounded-Corners\" is not compatible with KWin anymore.\n\nThis can probably be for an update.\nWe will now rebuild and reinstall the effect."
    p=$(kdialog --progressbar "Building KDE-Rounded-Corners...")
    $QDBUS_BIN $p showCancelButton false
    $QDBUS_BIN $p Set "" maximum "26"

    cmake -S "$SOURCE_DIR" -B "$BUILD_DIR" --install-prefix /usr
    $QDBUS_BIN $p Set "" value "2"

    cmake --build "$BUILD_DIR" --clean-first -j &
    pid=$!
    # Sleep for a short duration to let progress files to be created
    sleep 0.5

    # Loop until the cmake --build process is complete
    while kill -0 $pid 2>/dev/null; do
        maximum=$(( $(tail -n 1 CMakeFiles/Progress/count.txt 2>/dev/null || :) + 4))
        if [ "$maximum" -gt "0" ]; then
          value=$(( $(find CMakeFiles/Progress/ | wc -l) + 2))
          $QDBUS_BIN $p Set "" value "$value"
          $QDBUS_BIN $p Set "" maximum "$maximum"
        fi

        # Sleep for a short duration to avoid excessive CPU usage
        sleep 0.1
    done
    $QDBUS_BIN $p close


    kdialog --password "Enter password to install KDE-Rounded-Corners: " | sudo -S cmake --install "$BUILD_DIR"

    sh "$SCRIPT_DIR/load.sh"
    if ctest > /dev/null; then
      kdialog --msgbox "Desktop effect \"KDE-Rounded-Corners\" is now installed and loaded."
    else
      kdialog --error "The installation was not successful.\nSee logs by compiling manually."
    fi
fi
