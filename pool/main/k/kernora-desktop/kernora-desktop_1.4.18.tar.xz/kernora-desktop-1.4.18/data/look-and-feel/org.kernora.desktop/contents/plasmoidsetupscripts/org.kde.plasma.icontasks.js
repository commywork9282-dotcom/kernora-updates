applet.currentConfigGroup = ["General"];
applet.writeConfig("launchers", ["applications:librewolf.desktop", "applications:org.kernora.files.desktop", "applications:org.kernora.settings.desktop"]);
applet.reloadConfig();
