applet.currentConfigGroup = ["General"];
applet.writeConfig("favorites", "librewolf.desktop,org.kernora.files.desktop,org.kernora.settings.desktop,org.kernora.terminal.desktop");
applet.writeConfig("systemApplications", "org.kernora.settings.desktop");
applet.reloadConfig();
