desktops().forEach(function (desktop) {
    if (desktop.wallpaperPlugin === "org.kernora.marbles") {
        desktop.wallpaperPlugin = "org.kernora.pastel";
    }
});
