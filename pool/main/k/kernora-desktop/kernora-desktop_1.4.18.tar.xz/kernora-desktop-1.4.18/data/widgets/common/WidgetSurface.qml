/*
    SPDX-FileCopyrightText: 2026 Kernora Developers
    SPDX-License-Identifier: GPL-2.0-or-later
*/

import QtQuick
import "m3"

Rectangle {
    radius: M3.classic ? M3.cornerCard : 28
    color: M3.surfaceContainer
}
