<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<!-- Russian for the messages Calamares 3.3.14 leaves untranslated; loaded as
     the Kernora branding translation, which Qt asks after Calamares' own. -->
<TS version="2.1" language="ru">
<context>
    <name>Calamares::RequirementsChecker</name>
    <message numerus="yes">
        <source>Waiting for %n module(s)…</source>
        <comment>@status</comment>
        <translation>
            <numerusform>Ожидание %n модуля…</numerusform>
            <numerusform>Ожидание %n модулей…</numerusform>
            <numerusform>Ожидание %n модулей…</numerusform>
        </translation>
    </message>
</context>
<context>
    <name>CalamaresPython::Helper</name>
    <message>
        <source>Unparseable Python error</source>
        <comment>@error</comment>
        <translation>Не удалось разобрать ошибку Python</translation>
    </message>
    <message>
        <source>Unparseable Python traceback</source>
        <comment>@error</comment>
        <translation>Не удалось разобрать трассировку Python</translation>
    </message>
    <message>
        <source>Unfetchable Python error</source>
        <comment>@error</comment>
        <translation>Не удалось получить ошибку Python</translation>
    </message>
</context>
<context>
    <name>Config</name>
    <message>
        <source>Keyboard model has been set to %1.</source>
        <comment>@label, %1 is keyboard model, as in Apple Magic Keyboard</comment>
        <translation>Модель клавиатуры установлена на %1.</translation>
    </message>
    <message>
        <source>Set timezone to %1.</source>
        <comment>@action</comment>
        <translation>Часовым поясом будет установлен %1.</translation>
    </message>
</context>
<context>
    <name>ContextualProcessJob</name>
    <message>
        <source>Performing contextual processes' job…</source>
        <comment>@status</comment>
        <translation>Выполнение контекстных процессов…</translation>
    </message>
</context>
<context>
    <name>CreatePartitionJob</name>
    <message>
        <source>Create new %1MiB partition on %3 (%2) with entries %4</source>
        <comment>@title</comment>
        <translation>Создать новый раздел %1 МиБ на %3 (%2) с записями %4</translation>
    </message>
    <message>
        <source>Create new %1MiB partition on %3 (%2)</source>
        <comment>@title</comment>
        <translation>Создать новый раздел %1 МиБ на %3 (%2)</translation>
    </message>
    <message>
        <source>Create new &lt;strong&gt;%1MiB&lt;/strong&gt; partition on &lt;strong&gt;%3&lt;/strong&gt; (%2) with entries &lt;em&gt;%4&lt;/em&gt;</source>
        <comment>@info</comment>
        <translation>Создать новый раздел &lt;strong&gt;%1 МиБ&lt;/strong&gt; на &lt;strong&gt;%3&lt;/strong&gt; (%2) с записями &lt;em&gt;%4&lt;/em&gt;</translation>
    </message>
    <message>
        <source>Create new &lt;strong&gt;%1MiB&lt;/strong&gt; partition on &lt;strong&gt;%3&lt;/strong&gt; (%2)</source>
        <comment>@info</comment>
        <translation>Создать новый раздел &lt;strong&gt;%1 МиБ&lt;/strong&gt; на &lt;strong&gt;%3&lt;/strong&gt; (%2)</translation>
    </message>
    <message>
        <source>Create new &lt;strong&gt;%2MiB&lt;/strong&gt; partition on &lt;strong&gt;%4&lt;/strong&gt; (%3) with file system &lt;strong&gt;%1&lt;/strong&gt;</source>
        <comment>@info</comment>
        <translation>Создать новый раздел &lt;strong&gt;%2 МиБ&lt;/strong&gt; на &lt;strong&gt;%4&lt;/strong&gt; (%3) с файловой системой &lt;strong&gt;%1&lt;/strong&gt;</translation>
    </message>
</context>
<context>
    <name>CreatePartitionTableJob</name>
    <message>
        <source>Creating new &lt;strong&gt;%1&lt;/strong&gt; partition table on &lt;strong&gt;%2&lt;/strong&gt; (%3)…</source>
        <comment>@status</comment>
        <translation>Создание новой таблицы разделов &lt;strong&gt;%1&lt;/strong&gt; на &lt;strong&gt;%2&lt;/strong&gt; (%3)…</translation>
    </message>
</context>
<context>
    <name>DeactivateVolumeGroupJob</name>
    <message>
        <source>Deactivating volume group named %1…</source>
        <comment>@status</comment>
        <translation>Отключение группы томов %1…</translation>
    </message>
    <message>
        <source>Deactivating volume group named &lt;strong&gt;%1&lt;/strong&gt;…</source>
        <comment>@status</comment>
        <translation>Отключение группы томов &lt;strong&gt;%1&lt;/strong&gt;…</translation>
    </message>
</context>
<context>
    <name>FSArchiverRunner</name>
    <message>
        <source>Missing tools</source>
        <translation>Не хватает программ</translation>
    </message>
    <message>
        <source>The &lt;i&gt;%1&lt;/i&gt; tool is not installed on the system.</source>
        <translation>Программа &lt;i&gt;%1&lt;/i&gt; не установлена в системе.</translation>
    </message>
    <message>
        <source>Invalid fsarchiver configuration</source>
        <translation>Неверные настройки fsarchiver</translation>
    </message>
    <message>
        <source>The source archive &lt;i&gt;%1&lt;/i&gt; does not exist.</source>
        <translation>Исходного архива &lt;i&gt;%1&lt;/i&gt; не существует.</translation>
    </message>
    <message>
        <source>No destination could be found for &lt;i&gt;%1&lt;/i&gt;.</source>
        <translation>Не найдено место назначения для &lt;i&gt;%1&lt;/i&gt;.</translation>
    </message>
</context>
<context>
    <name>FillGlobalStorageJob</name>
    <message>
        <source>Set up &lt;strong&gt;new&lt;/strong&gt; %2 partition with mount point &lt;strong&gt;%1&lt;/strong&gt; and features &lt;em&gt;%3&lt;/em&gt;</source>
        <comment>@info</comment>
        <translation>Настроить &lt;strong&gt;новый&lt;/strong&gt; раздел %2 с точкой монтирования &lt;strong&gt;%1&lt;/strong&gt; и параметрами &lt;em&gt;%3&lt;/em&gt;</translation>
    </message>
    <message>
        <source>Set up &lt;strong&gt;new&lt;/strong&gt; %2 partition with mount point &lt;strong&gt;%1&lt;/strong&gt;%3</source>
        <comment>@info</comment>
        <translation>Настроить &lt;strong&gt;новый&lt;/strong&gt; раздел %2 с точкой монтирования &lt;strong&gt;%1&lt;/strong&gt;%3</translation>
    </message>
    <message>
        <source>Install %2 on %3 system partition &lt;strong&gt;%1&lt;/strong&gt; with features &lt;em&gt;%4&lt;/em&gt;</source>
        <comment>@info</comment>
        <translation>Установить %2 на системный раздел %3 &lt;strong&gt;%1&lt;/strong&gt; с параметрами &lt;em&gt;%4&lt;/em&gt;</translation>
    </message>
    <message>
        <source>Install %2 on %3 system partition &lt;strong&gt;%1&lt;/strong&gt;</source>
        <comment>@info</comment>
        <translation>Установить %2 на системный раздел %3 &lt;strong&gt;%1&lt;/strong&gt;</translation>
    </message>
    <message>
        <source>Set up %3 partition &lt;strong&gt;%1&lt;/strong&gt; with mount point &lt;strong&gt;%2&lt;/strong&gt; and features &lt;em&gt;%4&lt;/em&gt;</source>
        <comment>@info</comment>
        <translation>Настроить раздел %3 &lt;strong&gt;%1&lt;/strong&gt; с точкой монтирования &lt;strong&gt;%2&lt;/strong&gt; и параметрами &lt;em&gt;%4&lt;/em&gt;</translation>
    </message>
    <message>
        <source>Set up %3 partition &lt;strong&gt;%1&lt;/strong&gt; with mount point &lt;strong&gt;%2&lt;/strong&gt;%4…</source>
        <comment>@info</comment>
        <translation>Настроить раздел %3 &lt;strong&gt;%1&lt;/strong&gt; с точкой монтирования &lt;strong&gt;%2&lt;/strong&gt;%4…</translation>
    </message>
</context>
<context>
    <name>FormatPartitionJob</name>
    <message>
        <source>Format &lt;strong&gt;%3MiB&lt;/strong&gt; partition &lt;strong&gt;%1&lt;/strong&gt; with file system &lt;strong&gt;%2&lt;/strong&gt;</source>
        <comment>@info</comment>
        <translation>Форматировать раздел &lt;strong&gt;%1&lt;/strong&gt; (&lt;strong&gt;%3 МиБ&lt;/strong&gt;) в файловую систему &lt;strong&gt;%2&lt;/strong&gt;</translation>
    </message>
</context>
<context>
    <name>PWQ</name>
    <message numerus="yes">
        <source>The password contains fewer than %n uppercase letters</source>
        <translation>
            <numerusform>В пароле меньше %n заглавной буквы</numerusform>
            <numerusform>В пароле меньше %n заглавных букв</numerusform>
            <numerusform>В пароле меньше %n заглавных букв</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <source>The password contains fewer than %n non-alphanumeric characters</source>
        <translation>
            <numerusform>В пароле меньше %n символа, кроме букв и цифр</numerusform>
            <numerusform>В пароле меньше %n символов, кроме букв и цифр</numerusform>
            <numerusform>В пароле меньше %n символов, кроме букв и цифр</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <source>The password is shorter than %n characters</source>
        <translation>
            <numerusform>Пароль короче %n символа</numerusform>
            <numerusform>Пароль короче %n символов</numerusform>
            <numerusform>Пароль короче %n символов</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <source>The password contains fewer than %n character classes</source>
        <translation>
            <numerusform>В пароле меньше %n класса символов</numerusform>
            <numerusform>В пароле меньше %n классов символов</numerusform>
            <numerusform>В пароле меньше %n классов символов</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <source>The password contains more than %n same characters consecutively</source>
        <translation>
            <numerusform>В пароле больше %n одинакового символа подряд</numerusform>
            <numerusform>В пароле больше %n одинаковых символов подряд</numerusform>
            <numerusform>В пароле больше %n одинаковых символов подряд</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <source>The password contains more than %n characters of the same class consecutively</source>
        <translation>
            <numerusform>В пароле больше %n символа одного класса подряд</numerusform>
            <numerusform>В пароле больше %n символов одного класса подряд</numerusform>
            <numerusform>В пароле больше %n символов одного класса подряд</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <source>The password contains monotonic sequence longer than %n characters</source>
        <translation>
            <numerusform>В пароле монотонная последовательность длиннее %n символа</numerusform>
            <numerusform>В пароле монотонная последовательность длиннее %n символов</numerusform>
            <numerusform>В пароле монотонная последовательность длиннее %n символов</numerusform>
        </translation>
    </message>
</context>
<context>
    <name>PartitionViewStep</name>
    <message>
        <source>Create a swap file.</source>
        <translation>Создать файл подкачки.</translation>
    </message>
</context>
<context>
    <name>PreserveFiles</name>
    <message>
        <source>Saving files for later…</source>
        <comment>@status</comment>
        <translation>Сохранение файлов…</translation>
    </message>
</context>
<context>
    <name>ResizePartitionJob</name>
    <message>
        <source>Resize &lt;strong&gt;%2MiB&lt;/strong&gt; partition &lt;strong&gt;%1&lt;/strong&gt; to &lt;strong&gt;%3MiB&lt;/strong&gt;</source>
        <comment>@info</comment>
        <translation>Изменить размер раздела &lt;strong&gt;%1&lt;/strong&gt; с &lt;strong&gt;%2 МиБ&lt;/strong&gt; до &lt;strong&gt;%3 МиБ&lt;/strong&gt;</translation>
    </message>
</context>
<context>
    <name>ResizeVolumeGroupJob</name>
    <message>
        <source>Resizing volume group named %1 from %2 to %3…</source>
        <comment>@status</comment>
        <translation>Изменение размера группы томов %1 с %2 до %3…</translation>
    </message>
</context>
<context>
    <name>SetPartFlagsJob</name>
    <message>
        <source>Clear flags on partition &lt;strong&gt;%1&lt;/strong&gt;</source>
        <comment>@info</comment>
        <translation>Снять флаги с раздела &lt;strong&gt;%1&lt;/strong&gt;</translation>
    </message>
    <message>
        <source>Clear flags on %1MiB &lt;strong&gt;%2&lt;/strong&gt; partition</source>
        <comment>@info</comment>
        <translation>Снять флаги с раздела &lt;strong&gt;%2&lt;/strong&gt; (%1 МиБ)</translation>
    </message>
    <message>
        <source>Set flags on partition &lt;strong&gt;%1&lt;/strong&gt; to &lt;strong&gt;%2&lt;/strong&gt;</source>
        <comment>@info</comment>
        <translation>Установить на разделе &lt;strong&gt;%1&lt;/strong&gt; флаги &lt;strong&gt;%2&lt;/strong&gt;</translation>
    </message>
    <message>
        <source>Set flags on %1MiB &lt;strong&gt;%2&lt;/strong&gt; partition to &lt;strong&gt;%3&lt;/strong&gt;</source>
        <comment>@info</comment>
        <translation>Установить на разделе &lt;strong&gt;%2&lt;/strong&gt; (%1 МиБ) флаги &lt;strong&gt;%3&lt;/strong&gt;</translation>
    </message>
    <message>
        <source>Set flags on new partition to &lt;strong&gt;%1&lt;/strong&gt;</source>
        <comment>@info</comment>
        <translation>Установить на новом разделе флаги &lt;strong&gt;%1&lt;/strong&gt;</translation>
    </message>
    <message>
        <source>Clearing flags on partition &lt;strong&gt;%1&lt;/strong&gt;…</source>
        <comment>@status</comment>
        <translation>Снятие флагов с раздела &lt;strong&gt;%1&lt;/strong&gt;…</translation>
    </message>
    <message>
        <source>Setting flags &lt;strong&gt;%2&lt;/strong&gt; on partition &lt;strong&gt;%1&lt;/strong&gt;…</source>
        <comment>@status</comment>
        <translation>Установка флагов &lt;strong&gt;%2&lt;/strong&gt; на раздел &lt;strong&gt;%1&lt;/strong&gt;…</translation>
    </message>
    <message>
        <source>Setting flags &lt;strong&gt;%3&lt;/strong&gt; on %1MiB &lt;strong&gt;%2&lt;/strong&gt; partition…</source>
        <comment>@status</comment>
        <translation>Установка флагов &lt;strong&gt;%3&lt;/strong&gt; на раздел &lt;strong&gt;%2&lt;/strong&gt; (%1 МиБ)…</translation>
    </message>
</context>
<context>
    <name>TarballRunner</name>
    <message>
        <source>Invalid tarball configuration</source>
        <translation>Неверные настройки архива tar</translation>
    </message>
    <message>
        <source>The source archive &lt;i&gt;%1&lt;/i&gt; does not exist.</source>
        <translation>Исходного архива &lt;i&gt;%1&lt;/i&gt; не существует.</translation>
    </message>
    <message>
        <source>Missing tools</source>
        <translation>Не хватает программ</translation>
    </message>
    <message>
        <source>The &lt;i&gt;%1&lt;/i&gt; tool is not installed on the system.</source>
        <translation>Программа &lt;i&gt;%1&lt;/i&gt; не установлена в системе.</translation>
    </message>
    <message>
        <source>No destination could be found for &lt;i&gt;%1&lt;/i&gt;.</source>
        <translation>Не найдено место назначения для &lt;i&gt;%1&lt;/i&gt;.</translation>
    </message>
    <message>
        <source>Tarball extract file %1</source>
        <translation>Распаковка архива %1</translation>
    </message>
</context>
<context>
    <name>UnpackFSCJob</name>
    <message>
        <source>Unpack filesystems</source>
        <translation>Распаковка файловых систем</translation>
    </message>
</context>
<context>
    <name>UnsquashRunner</name>
    <message>
        <source>Invalid unsquash configuration</source>
        <translation>Неверные настройки unsquash</translation>
    </message>
    <message>
        <source>The source archive &lt;i&gt;%1&lt;/i&gt; does not exist.</source>
        <translation>Исходного архива &lt;i&gt;%1&lt;/i&gt; не существует.</translation>
    </message>
    <message>
        <source>Missing tools</source>
        <translation>Не хватает программ</translation>
    </message>
    <message>
        <source>The &lt;i&gt;%1&lt;/i&gt; tool is not installed on the system.</source>
        <translation>Программа &lt;i&gt;%1&lt;/i&gt; не установлена в системе.</translation>
    </message>
    <message>
        <source>No destination could be found for &lt;i&gt;%1&lt;/i&gt;.</source>
        <translation>Не найдено место назначения для &lt;i&gt;%1&lt;/i&gt;.</translation>
    </message>
    <message>
        <source>Unsquash file %1</source>
        <translation>Распаковка образа %1</translation>
    </message>
</context>
<!-- The Kernora UI kit (org.kernora.ui) in the installer: without KDE's
     i18n there, its components fall back to qsTr, in the context of their
     file; the same Russian as kernora-ui.ru.po. -->
<context>
    <name>ChoiceDialog</name>
    <message>
        <source>Cancel</source>
        <translation>Отмена</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>Поиск</translation>
    </message>
</context>
<context>
    <name>Dialog</name>
    <message>
        <source>OK</source>
        <translation>ОК</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отмена</translation>
    </message>
</context>
<context>
    <name>InputField</name>
    <message>
        <source>Show password</source>
        <translation>Показать пароль</translation>
    </message>
    <message>
        <source>Hide password</source>
        <translation>Скрыть пароль</translation>
    </message>
</context>
<context>
    <name>Page</name>
    <message>
        <source>Back</source>
        <translation>Назад</translation>
    </message>
</context>
<context>
    <name>SearchField</name>
    <message>
        <source>Clear</source>
        <translation>Очистить</translation>
    </message>
</context>
</TS>
