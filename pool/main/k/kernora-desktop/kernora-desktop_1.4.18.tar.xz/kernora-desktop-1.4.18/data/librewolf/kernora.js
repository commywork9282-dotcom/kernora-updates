// SPDX-FileCopyrightText: 2026 Kernora Developers
// SPDX-License-Identifier: GPL-2.0-or-later

pref("xpinstall.signatures.required", false);
pref("extensions.activeThemeID", "theme@kernora.os");

pref("widget.use-xdg-desktop-portal.file-picker", 1);
pref("toolkit.legacyUserProfileCustomizations.stylesheets", true);
